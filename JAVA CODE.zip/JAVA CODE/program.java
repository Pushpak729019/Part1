class program
{
public static void main(String agrs[])
{
System.out.println("this is first proram");
}
}