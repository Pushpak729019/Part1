public class first_program
{
	public static void main(String agrs[])
	{
		system.out.println("HELLO WORLD")
	}
}