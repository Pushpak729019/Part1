//DSAL Assignment 3.

/*A book consists of chapters, chapters consist of sections and sections consist of 
subsections. Construct a tree and print the nodes. Find the time and space requirements of 
your method.*/

#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;

struct node{
    char name[20];
    node *next;
    node *down;
    int flag;
};

class Gll{
    char ch[20]; int n, i;
    node *head=NULL, *t1=NULL, *t2=NULL;

    public:
        node*create();
        void insertb();
        void insertc();
        void inserts();
        void insertss();
        void displayb();
};

node *Gll::create()
{
    node *p=new(struct node);
    p->next=NULL;
    p->down=-NULL;
    p->flag=0;
    cout<<"\n Enter the name:";
    cin>>p->name;
    return p;
}

void Gll::insertb(){
    if(head==NULL){
        t1=create();
        head=t1;
    }
    else{
        cout<<"\n Book Exist.";
    }
}

void Gll::insertc(){
    if(head==NULL){
        cout<<"\n There is a book.";
    
    }
    else{
        cout<<"\n How many chppters you want to insert.";
        cin>>n;
        for(i=0; i<n; i++){
            t1=create();
            if(head->flag==0)
            {
                head->down=t1; head->flag=1;
            }
            else
			{
                temp=head;
                temp=temp->down;
                while(temp->next!=NULL)
                    temp=temp->next;
                    temp->next=t1;                
                
            }
        }
    }
}

void Gll::inserts(){
    if(head==NULL){
        cout<<"\n There is no book";
    }
    else{
        cout<<"\n Enter the name of chapter on which you want to enter the section";
        cin>>ch;
    }
}
